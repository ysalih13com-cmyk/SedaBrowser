# Ozel kural gerekmiyor.
